#!/bin/bash

ceph mon remove $(hostname -s)