Description
===========

This directory contains example scripts and helpers for different base
operating systems.  

