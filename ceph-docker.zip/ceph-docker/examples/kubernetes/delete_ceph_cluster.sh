#!/bin/bash

kubectl delete namespace ceph
